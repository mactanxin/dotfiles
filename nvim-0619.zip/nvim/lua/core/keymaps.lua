local opts = { noremap = true, silent = true }

local term_opts = { silent = true }

-- Shorten function name
local keymap = vim.api.nvim_set_keymap
keymap("", "<Space>", "<Nop>", opts)
keymap("", ";", ":", opts)
keymap("", "s", "<Nop>", opts)
keymap("", "R", "<Nop>", opts)

vim.g.mapleader = " "
vim.g.maplocalleader = " "

local function mapkey(mode, lhs, rhs)
    vim.api.nvim_set_keymap(mode, lhs, rhs, {noremap=true})
end

local function mapcmd(key, cmd)
    vim.api.nvim_set_keymap('n', key, ':'..cmd..'<cr>', {noremap=true})
end

local function maplua(key, txt)
    vim.api.nvim_set_keymap('n', key, ':lua '..txt..'<cr>', {noremap=true})
end

--Remap space as leader key

mapcmd("S", "w")
mapcmd("<LEADER><CR>", "noh")

-- Modes
--   normal_mode = "n",
--   insert_mode = "i",
--   visual_mode = "v",
--   visual_block_mode = "x",
--   term_mode = "t",
--   command_mode = "c",
--
keymap("n", "S", ":w<CR>", opts)
keymap("n", "Q", ":q<CR>", opts)
keymap("", "R", ":source $MYVIMRC<CR>", opts)
keymap("", "cd", ":chdir", opts)

-- -- Toggle NERDTree
-- keymap("n", "tt", ":NERDTreeToggle<CR>", opts)
mapcmd("tt", ":NERDTreeToggle")
mapcmd("<LEADER>r", ":NvimTreeRefresh")

-- coc quick actions
keymap("n", "[g", "<Plug>(coc-diagnostic-prev)", opts)
keymap("n", "]g", "<Plug>(coc-diagnostic-next)", opts)
keymap("n", "gd", "<Plug>(coc-definition)", opts)
keymap("n", "gy", "<Plug>(coc-type-definition)", opts)
keymap("n", "gi", "<Plug>(coc-implementation)", opts)
keymap("n", "gr", "<Plug>(coc-references)", opts)
-- jump back and forth in frames
mapkey("n", "<LEADER>l", "<C-w>l", opts)
mapkey("n", "<LEADER>h", "<C-w>h", opts)
mapkey("n", "<LEADER>j", "<C-w>j", opts)
mapkey("n", "<LEADER>k", "<C-w>k", opts)
mapkey("n", "<LEADER><LEADER>", "<C-f>", opts)
mapkey("n", "<LEADER>bb", "<C-b>", opts)
mapkey("n", "<LEADER>sv", "<C-w>t<C-w>H", opts)
mapkey("n", "<LEADER>sh", "<C-w>t<C-w>K", opts)

keymap("", "<LEADER>cd", ":cd %:p:h<CR>:pwd<CR>", opts)
mapcmd("<LEADER>ss", ":SaveSession")
mapcmd("<LEADER>sl", ":RestoreSession")


-- GoTo Tabs by number
keymap("", "<LEADER>1", "1gt", opts)
keymap("", "<LEADER>2", "2gt", opts)
keymap("", "<LEADER>3", "3gt", opts)
keymap("", "<LEADER>4", "4gt", opts)
keymap("", "<LEADER>5", "5gt", opts)
keymap("", "<LEADER>6", "6gt", opts)
keymap("", "<LEADER>7", "7gt", opts)
keymap("", "<LEADER>8", "8gt", opts)
keymap("", "<LEADER>9", "9gt", opts)
keymap("", "<LEADER>9", "9gt", opts)
keymap("", "<LEADER>0", ":tablast<CR>", opts)

-- split
mapcmd("sl", "set splitright<CR>:vsplit<CR>")
mapcmd("sh", "set nosplitright<CR>:vsplit<CR>")
mapcmd("sk", "set splitbelow<CR>:split<CR>")
mapcmd("sj", "set splitbelow<CR>:split<CR>")

-- change split size using alt+arrow
mapcmd("<M-left>", "vertical resize -5<cr>")
mapcmd("<M-down>", "resize +5<cr>")
mapcmd("<M-up>", "resize -5<cr>")
mapcmd("<M-right>", "vertical resize +5<cr>")

mapcmd("tn", "tabe")
mapcmd("th", "-tabnext")
mapcmd("tl", "+tabnext")

mapkey("n", ";ff", "<cmd>Telescope find_files<CR>", opts)
mapkey("n", ";fg", "<cmd>Telescope live_grep<cr>", opts)
mapkey("n", ";fb", "<cmd>Telescope buffers<cr>", opts)
mapkey("n", ";fh", "<cmd>Telescope help_tags<cr>", opts)
maplua(";fs", "require('session-lens').search_session()")
-- SarchBox Key Bindings
mapcmd("<LEADER>s", "SearchBoxIncSearch")
mapcmd("<LEADER>r", "SearchBoxReplace confirm=menu")